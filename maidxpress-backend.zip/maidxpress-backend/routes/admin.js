const store = require('../lib/store');
const { newId } = require('../lib/id');

function register(router, requireAuth) {
  // ---- Riders ----
  router.get('/api/admin/riders', requireAuth('admin'), async (req, res) => {
    const riders = await store.all('riders');
    res.json(200, riders.map(({ password, ...safe }) => safe));
  });

  router.post('/api/admin/riders/:id/approve', requireAuth('admin'), async (req, res) => {
    const updated = await store.update('riders', req.params.id, { status: 'approved' });
    if (!updated) return res.json(404, { error: 'Rider not found.' });
    const { password, ...safe } = updated;
    res.json(200, safe);
  });

  router.post('/api/admin/riders/:id/reject', requireAuth('admin'), async (req, res, body) => {
    const updated = await store.update('riders', req.params.id, {
      status: 'rejected',
      rejectionReason: body.reason || '',
    });
    if (!updated) return res.json(404, { error: 'Rider not found.' });
    const { password, ...safe } = updated;
    res.json(200, safe);
  });

  // ---- Customers ----
  router.get('/api/admin/customers', requireAuth('admin'), async (req, res) => {
    const customers = await store.all('customers');
    res.json(200, customers.map(({ password, ...safe }) => safe));
  });

  // ---- Deliveries ----
  router.get('/api/admin/deliveries', requireAuth('admin'), async (req, res) => {
    const deliveries = await store.all('deliveries');
    res.json(200, deliveries.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)));
  });

  router.post('/api/admin/deliveries/:id/confirm-payment', requireAuth('admin'), async (req, res) => {
    const delivery = await store.find('deliveries', (d) => d.id === req.params.id);
    if (!delivery) return res.json(404, { error: 'Delivery not found.' });
    const updated = await store.update('deliveries', delivery.id, {
      paymentStatus: 'confirmed',
      status: delivery.status === 'pending_payment' ? 'confirmed' : delivery.status,
    });
    res.json(200, updated);
  });

  router.post('/api/admin/deliveries/:id/assign', requireAuth('admin'), async (req, res, body) => {
    const delivery = await store.find('deliveries', (d) => d.id === req.params.id);
    if (!delivery) return res.json(404, { error: 'Delivery not found.' });
    if (!body.riderId) return res.json(400, { error: 'riderId is required.' });
    const rider = await store.find('riders', (r) => r.id === body.riderId && r.status === 'approved');
    if (!rider) return res.json(404, { error: 'Approved rider not found.' });
    const updated = await store.update('deliveries', delivery.id, {
      assignedRiderId: rider.id,
      status: 'assigned',
    });
    res.json(200, updated);
  });

  // ---- Withdrawals ----
  router.get('/api/admin/withdrawals', requireAuth('admin'), async (req, res) => {
    const withdrawals = await store.all('withdrawals');
    res.json(200, withdrawals.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)));
  });

  router.post('/api/admin/withdrawals/:id/approve', requireAuth('admin'), async (req, res) => {
    const updated = await store.update('withdrawals', req.params.id, { status: 'approved' });
    if (!updated) return res.json(404, { error: 'Withdrawal request not found.' });
    res.json(200, updated);
  });

  router.post('/api/admin/withdrawals/:id/reject', requireAuth('admin'), async (req, res) => {
    const wd = await store.find('withdrawals', (w) => w.id === req.params.id);
    if (!wd) return res.json(404, { error: 'Withdrawal request not found.' });
    // Refund the held amount back to the rider's wallet
    const rider = await store.find('riders', (r) => r.id === wd.riderId);
    if (rider) {
      await store.update('riders', rider.id, { walletBalance: (rider.walletBalance || 0) + wd.amount });
      await store.insert('wallet_tx', {
        id: newId('wtx'),
        riderId: rider.id,
        type: 'credit',
        amount: wd.amount,
        reason: 'Withdrawal request rejected — refunded',
        createdAt: new Date().toISOString(),
      });
    }
    const updated = await store.update('withdrawals', wd.id, { status: 'rejected' });
    res.json(200, updated);
  });

  // ---- Promo codes ----
  router.get('/api/admin/promo-codes', requireAuth('admin'), async (req, res) => {
    res.json(200, await store.all('promo_codes'));
  });

  router.post('/api/admin/promo-codes', requireAuth('admin'), async (req, res, body) => {
    const { code, percentOff, expiresAt } = body;
    if (!code || !percentOff) return res.json(400, { error: 'code and percentOff are required.' });
    const record = {
      id: newId('promo'),
      code: code.toUpperCase(),
      percentOff: Number(percentOff),
      expiresAt: expiresAt || null,
      active: true,
      createdAt: new Date().toISOString(),
    };
    await store.insert('promo_codes', record);
    res.json(201, record);
  });

  // ---- Analytics ----
  router.get('/api/admin/analytics', requireAuth('admin'), async (req, res) => {
    const [customers, riders, deliveries, withdrawals] = await Promise.all([
      store.all('customers'), store.all('riders'), store.all('deliveries'), store.all('withdrawals'),
    ]);
    const byStatus = {};
    deliveries.forEach((d) => { byStatus[d.status] = (byStatus[d.status] || 0) + 1; });
    res.json(200, {
      totalCustomers: customers.length,
      totalRiders: riders.length,
      approvedRiders: riders.filter((r) => r.status === 'approved').length,
      pendingRiders: riders.filter((r) => r.status === 'pending').length,
      totalDeliveries: deliveries.length,
      deliveriesByStatus: byStatus,
      pendingWithdrawals: withdrawals.filter((w) => w.status === 'pending').length,
    });
  });
}

module.exports = { register };
