const store = require('../lib/store');

function register(router) {
  router.get('/api/track/:code', async (req, res) => {
    const code = req.params.code.toUpperCase();
    const delivery = await store.find('deliveries', (d) => d.trackingNumber.toUpperCase() === code);
    if (!delivery) return res.json(404, { error: 'No delivery found with that tracking number.' });

    let riderName = null;
    let riderPhone = null;
    if (delivery.assignedRiderId) {
      const rider = await store.find('riders', (r) => r.id === delivery.assignedRiderId);
      if (rider) { riderName = rider.fullName; riderPhone = rider.phone; }
    }

    res.json(200, {
      trackingNumber: delivery.trackingNumber,
      status: delivery.status,
      lastLocation: delivery.lastLocation || null,
      assignedRider: riderName ? { name: riderName, phone: riderPhone } : null,
      createdAt: delivery.createdAt,
    });
  });
}

module.exports = { register };
