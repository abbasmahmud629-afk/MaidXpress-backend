const store = require('../lib/store');
const { newId } = require('../lib/id');

const VALID_STATUSES = ['picked_up', 'in_transit', 'delivered'];

function register(router, requireAuth) {
  router.get('/api/rider/me', requireAuth('rider'), async (req, res) => {
    const r = await store.find('riders', (x) => x.id === req.user.sub);
    if (!r) return res.json(404, { error: 'Not found.' });
    const { password, ...safe } = r;
    res.json(200, safe);
  });

  router.get('/api/rider/deliveries/available', requireAuth('rider'), async (req, res) => {
    const available = await store.filter('deliveries', (d) => d.status === 'confirmed' && !d.assignedRiderId);
    res.json(200, available);
  });

  router.get('/api/rider/deliveries/mine', requireAuth('rider'), async (req, res) => {
    const mine = await store.filter('deliveries', (d) => d.assignedRiderId === req.user.sub);
    res.json(200, mine.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)));
  });

  router.post('/api/rider/deliveries/:id/accept', requireAuth('rider'), async (req, res) => {
    const delivery = await store.find('deliveries', (d) => d.id === req.params.id);
    if (!delivery) return res.json(404, { error: 'Delivery not found.' });
    if (delivery.assignedRiderId) return res.json(409, { error: 'This delivery is already assigned.' });
    const updated = await store.update('deliveries', delivery.id, {
      assignedRiderId: req.user.sub,
      status: 'assigned',
    });
    res.json(200, updated);
  });

  router.post('/api/rider/deliveries/:id/status', requireAuth('rider'), async (req, res, body) => {
    const delivery = await store.find('deliveries', (d) => d.id === req.params.id && d.assignedRiderId === req.user.sub);
    if (!delivery) return res.json(404, { error: 'Delivery not found or not assigned to you.' });
    if (!VALID_STATUSES.includes(body.status)) {
      return res.json(400, { error: `status must be one of: ${VALID_STATUSES.join(', ')}` });
    }
    const logEntry = {
      status: body.status,
      lat: typeof body.lat === 'number' ? body.lat : null,
      lng: typeof body.lng === 'number' ? body.lng : null,
      at: new Date().toISOString(),
    };
    const locationLog = [...(delivery.locationLog || []), logEntry];
    const patch = { status: body.status, locationLog };
    if (logEntry.lat !== null && logEntry.lng !== null) {
      patch.lastLocation = { lat: logEntry.lat, lng: logEntry.lng };
    }

    // Credit rider wallet on delivery completion (flat fee placeholder —
    // wire this to your real pricing calculator later).
    if (body.status === 'delivered') {
      const fee = Number(body.earnedAmount) > 0 ? Number(body.earnedAmount) : 1500;
      const rider = await store.find('riders', (r) => r.id === req.user.sub);
      await store.update('riders', rider.id, { walletBalance: (rider.walletBalance || 0) + fee });
      await store.insert('wallet_tx', {
        id: newId('wtx'),
        riderId: rider.id,
        type: 'credit',
        amount: fee,
        reason: `Delivery ${delivery.trackingNumber} completed`,
        createdAt: new Date().toISOString(),
      });
    }

    const updated = await store.update('deliveries', delivery.id, patch);
    res.json(200, updated);
  });

  // Live GPS ping — call this periodically from the rider's browser via
  // navigator.geolocation while a delivery is in progress.
  router.post('/api/rider/location', requireAuth('rider'), async (req, res, body) => {
    const { deliveryId, lat, lng } = body;
    if (typeof lat !== 'number' || typeof lng !== 'number') {
      return res.json(400, { error: 'lat and lng (numbers) are required.' });
    }
    if (deliveryId) {
      const delivery = await store.find('deliveries', (d) => d.id === deliveryId && d.assignedRiderId === req.user.sub);
      if (delivery) {
        const locationLog = [...(delivery.locationLog || []), { lat, lng, at: new Date().toISOString(), ping: true }];
        await store.update('deliveries', delivery.id, { locationLog, lastLocation: { lat, lng } });
      }
    }
    await store.update('riders', req.user.sub, { lastLocation: { lat, lng, at: new Date().toISOString() } });
    res.json(200, { ok: true });
  });

  router.get('/api/rider/wallet', requireAuth('rider'), async (req, res) => {
    const rider = await store.find('riders', (r) => r.id === req.user.sub);
    const tx = await store.filter('wallet_tx', (t) => t.riderId === req.user.sub);
    const withdrawals = await store.filter('withdrawals', (w) => w.riderId === req.user.sub);
    res.json(200, {
      balance: rider.walletBalance || 0,
      transactions: tx.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)),
      withdrawals: withdrawals.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)),
    });
  });

  router.post('/api/rider/wallet/withdraw', requireAuth('rider'), async (req, res, body) => {
    const { amount, destinationBank, destinationAccountNumber, destinationAccountName } = body;
    const amt = Number(amount);
    if (!amt || amt <= 0) return res.json(400, { error: 'A valid amount is required.' });
    const rider = await store.find('riders', (r) => r.id === req.user.sub);
    if (amt > (rider.walletBalance || 0)) return res.json(400, { error: 'Insufficient wallet balance.' });
    if (!destinationBank || !destinationAccountNumber || !destinationAccountName) {
      return res.json(400, { error: 'Destination bank, account number and account name are required.' });
    }
    const withdrawal = {
      id: newId('wd'),
      riderId: rider.id,
      amount: amt,
      destinationBank, destinationAccountNumber, destinationAccountName,
      status: 'pending', // pending -> approved / rejected (admin actions)
      createdAt: new Date().toISOString(),
    };
    await store.insert('withdrawals', withdrawal);
    // Hold the funds so it can't be withdrawn twice while pending
    await store.update('riders', rider.id, { walletBalance: (rider.walletBalance || 0) - amt });
    await store.insert('wallet_tx', {
      id: newId('wtx'),
      riderId: rider.id,
      type: 'debit',
      amount: amt,
      reason: 'Withdrawal request submitted',
      createdAt: new Date().toISOString(),
    });
    res.json(201, withdrawal);
  });
}

module.exports = { register };
