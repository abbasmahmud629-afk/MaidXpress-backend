const store = require('../lib/store');
const { hashPassword, verifyPassword, signToken } = require('../lib/auth');
const { newId } = require('../lib/id');
const { saveDataUri } = require('../lib/uploads');

function isEmail(v) {
  return typeof v === 'string' && /\S+@\S+\.\S+/.test(v);
}

async function findAnyByEmail(email) {
  const admin = adminAccount();
  if (admin.email.toLowerCase() === email.toLowerCase()) {
    return { role: 'admin', record: admin };
  }
  const customer = await store.find('customers', (c) => c.email.toLowerCase() === email.toLowerCase());
  if (customer) return { role: 'customer', record: customer };
  const rider = await store.find('riders', (r) => r.email.toLowerCase() === email.toLowerCase());
  if (rider) return { role: 'rider', record: rider };
  return null;
}

function adminAccount() {
  return {
    id: 'admin_root',
    email: process.env.ADMIN_EMAIL || 'admin@maidxpress.com',
    password: hashPassword(process.env.ADMIN_PASSWORD || 'ChangeMe123!'),
    fullName: 'MaidXpress Admin',
  };
}

function register(router) {
  router.post('/api/auth/register-customer', async (req, res, body) => {
    const { fullName, email, phone, password, address } = body;
    if (!fullName || !isEmail(email) || !phone || !password || !address) {
      return res.json(400, { error: 'fullName, email, phone, password and address are required.' });
    }
    const existing = await store.find('customers', (c) => c.email.toLowerCase() === email.toLowerCase());
    if (existing) return res.json(409, { error: 'An account with this email already exists.' });

    const record = {
      id: newId('cust'),
      fullName, email, phone, address,
      password: hashPassword(password),
      createdAt: new Date().toISOString(),
    };
    await store.insert('customers', record);
    const token = signToken({ sub: record.id, role: 'customer' });
    res.json(201, { token, role: 'customer', fullName: record.fullName });
  });

  router.post('/api/auth/register-rider', async (req, res, body) => {
    const {
      fullName, email, phone, password, address,
      ninSlip, passport,
      nextOfKinName, nextOfKinPhone, nextOfKinNin, nextOfKinAddress,
    } = body;

    if (!fullName || !isEmail(email) || !phone || !password || !address) {
      return res.json(400, { error: 'fullName, email, phone, password and address are required.' });
    }
    if (!ninSlip || !passport) {
      return res.json(400, { error: 'NIN slip and passport photograph uploads are required.' });
    }
    if (!nextOfKinName || !nextOfKinPhone || !nextOfKinNin || !nextOfKinAddress) {
      return res.json(400, { error: 'Next of kin name, phone, NIN and address are required.' });
    }
    const existing = await store.find('riders', (r) => r.email.toLowerCase() === email.toLowerCase());
    if (existing) return res.json(409, { error: 'An account with this email already exists.' });

    const ninSlipPath = saveDataUri(ninSlip, 'nin');
    const passportPath = saveDataUri(passport, 'passport');
    if (!ninSlipPath || !passportPath) {
      return res.json(400, { error: 'Could not read uploaded files. Please re-upload and try again.' });
    }

    const record = {
      id: newId('rider'),
      fullName, email, phone, address,
      password: hashPassword(password),
      ninSlipPath, passportPath,
      nextOfKin: { name: nextOfKinName, phone: nextOfKinPhone, nin: nextOfKinNin, address: nextOfKinAddress },
      status: 'pending', // pending -> approved / rejected, set by admin
      walletBalance: 0,
      createdAt: new Date().toISOString(),
    };
    await store.insert('riders', record);
    res.json(201, {
      message: 'Registration received. Your documents are being reviewed — you will be contacted once approved.',
      riderId: record.id,
    });
  });

  router.post('/api/auth/login', async (req, res, body) => {
    const { email, password } = body;
    if (!isEmail(email) || !password) return res.json(400, { error: 'Email and password are required.' });

    const found = await findAnyByEmail(email);
    if (!found || !verifyPassword(password, found.record.password)) {
      return res.json(401, { error: 'Invalid email or password.' });
    }
    if (found.role === 'rider' && found.record.status !== 'approved') {
      return res.json(403, { error: `Your rider account is ${found.record.status}. You'll get access once approved.` });
    }
    const token = signToken({ sub: found.record.id, role: found.role });
    res.json(200, { token, role: found.role, fullName: found.record.fullName });
  });
}

module.exports = { register, adminAccount };
