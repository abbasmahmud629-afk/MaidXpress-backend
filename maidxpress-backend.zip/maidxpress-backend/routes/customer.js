const store = require('../lib/store');
const { newId, trackingNumber } = require('../lib/id');
const { saveDataUri } = require('../lib/uploads');

function register(router, requireAuth) {
  router.get('/api/customer/me', requireAuth('customer'), async (req, res) => {
    const c = await store.find('customers', (x) => x.id === req.user.sub);
    if (!c) return res.json(404, { error: 'Not found.' });
    const { password, ...safe } = c;
    res.json(200, safe);
  });

  router.post('/api/customer/deliveries', requireAuth('customer'), async (req, res, body) => {
    const {
      pickupAddress, deliveryAddress, receiverName, receiverPhone,
      packageType, weight, instructions, paymentMethod,
    } = body;
    if (!pickupAddress || !deliveryAddress || !receiverName || !receiverPhone || !packageType) {
      return res.json(400, { error: 'pickupAddress, deliveryAddress, receiverName, receiverPhone and packageType are required.' });
    }
    let code = trackingNumber();
    // Guarantee uniqueness
    while (await store.find('deliveries', (d) => d.trackingNumber === code)) {
      code = trackingNumber();
    }
    const record = {
      id: newId('del'),
      trackingNumber: code,
      customerId: req.user.sub,
      pickupAddress, deliveryAddress, receiverName, receiverPhone,
      packageType, weight: weight || null, instructions: instructions || '',
      paymentMethod: paymentMethod || 'bank_transfer',
      paymentStatus: 'awaiting_confirmation', // customer must send receipt on WhatsApp
      status: 'pending_payment', // pending_payment -> confirmed -> assigned -> picked_up -> in_transit -> delivered
      assignedRiderId: null,
      locationLog: [],
      createdAt: new Date().toISOString(),
    };
    await store.insert('deliveries', record);
    res.json(201, {
      message: 'Booking created. Send your payment receipt on WhatsApp to confirm and get a rider assigned.',
      trackingNumber: code,
      delivery: record,
    });
  });

  router.get('/api/customer/deliveries', requireAuth('customer'), async (req, res) => {
    const mine = await store.filter('deliveries', (d) => d.customerId === req.user.sub);
    res.json(200, mine.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)));
  });

  // Optional: attach a payment receipt image to a booking for record-keeping,
  // in addition to sending it on WhatsApp.
  router.post('/api/customer/deliveries/:id/receipt', requireAuth('customer'), async (req, res, body) => {
    const delivery = await store.find('deliveries', (d) => d.id === req.params.id && d.customerId === req.user.sub);
    if (!delivery) return res.json(404, { error: 'Delivery not found.' });
    const receiptPath = saveDataUri(body.receipt, 'receipt');
    if (!receiptPath) return res.json(400, { error: 'Could not read uploaded receipt image.' });
    const updated = await store.update('deliveries', delivery.id, { receiptPath, paymentStatus: 'receipt_uploaded' });
    res.json(200, updated);
  });
}

module.exports = { register };
